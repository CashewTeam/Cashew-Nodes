import bpy

from ..mapping import arp as mapping_arp
from ..mapping import mmd as mapping_mmd
from ..mapping import mapper as mapping
from ..mapping import preset_store as presets
from ..mapping import vrm as mapping_vrm
from ..preview import dummy_vrm
from ..runtime import driver as runtime
from ..runtime import network


def _ensure_target_rig_type(scene, rig_type: str):
    current = str(getattr(scene, "vmc_link_target_rig_type", "")).strip().upper()
    wanted = str(rig_type).strip().upper()
    if current == wanted:
        return
    scene.vmc_link_target_rig_type = wanted


def _finalize_mapping_update(scene):
    mapping.rebuild_maps(scene)
    runtime.refresh_receiver_target_context(scene)
    runtime.tag_view3d_ui_redraw()


class VMC_LINK_OT_toggle_receiver(bpy.types.Operator):
    bl_idname = "vmc_link.toggle_receiver"
    bl_label = "切换接收器"

    def execute(self, context):
        scene = context.scene
        try:
            if network.is_session_active():
                network.stop_server(scene)
                self.report({"INFO"}, "VMC Link 接收器已停止")
            else:
                network.start_server(scene)
                self.report({"INFO"}, f"VMC Link 接收器已启动：{runtime.describe_receiver_endpoints(scene)}")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_start_receiver(bpy.types.Operator):
    bl_idname = "vmc_link.start_receiver"
    bl_label = "启动接收"

    def execute(self, context):
        scene = context.scene
        try:
            network.start_server(scene)
            self.report({"INFO"}, f"VMC Link 接收器已启动：{runtime.describe_receiver_endpoints(scene)}")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_pause_receiver(bpy.types.Operator):
    bl_idname = "vmc_link.pause_receiver"
    bl_label = "暂停或继续接收"

    def execute(self, context):
        scene = context.scene
        try:
            if network.is_paused():
                network.resume_server(scene)
                self.report({"INFO"}, "VMC Link 接收器已继续")
            else:
                network.pause_server(scene)
                self.report({"INFO"}, "VMC Link 接收器已暂停")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_stop_receiver(bpy.types.Operator):
    bl_idname = "vmc_link.stop_receiver"
    bl_label = "停止接收"

    def execute(self, context):
        scene = context.scene
        try:
            network.stop_server(scene)
            self.report({"INFO"}, "VMC Link 接收器已停止并恢复骨架初始状态")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_refresh_mapping_presets(bpy.types.Operator):
    bl_idname = "vmc_link.refresh_mapping_presets"
    bl_label = "刷新映射预设"

    mapping_kind: bpy.props.StringProperty()

    def execute(self, context):
        kind = str(self.mapping_kind)
        try:
            presets.refresh_mapping_presets(context.scene, kind)
            self.report({"INFO"}, f"已刷新 {mapping.mapping_kind_label(kind)} 预设")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_save_mapping_preset(bpy.types.Operator):
    bl_idname = "vmc_link.save_mapping_preset"
    bl_label = "保存映射预设"

    mapping_kind: bpy.props.StringProperty()

    def execute(self, context):
        kind = str(self.mapping_kind)
        try:
            file_name = presets.save_mapping_preset(context.scene, kind)
            self.report({"INFO"}, f"已保存 {mapping.mapping_kind_label(kind)} 预设：{file_name}")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_load_mapping_preset(bpy.types.Operator):
    bl_idname = "vmc_link.load_mapping_preset"
    bl_label = "加载映射预设"

    mapping_kind: bpy.props.StringProperty()

    def execute(self, context):
        kind = str(self.mapping_kind)
        try:
            file_name = presets.load_mapping_preset(context.scene, kind)
            _finalize_mapping_update(context.scene)
            self.report({"INFO"}, f"已加载 {mapping.mapping_kind_label(kind)} 预设：{file_name}")
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_create_dummy_armature(bpy.types.Operator):
    bl_idname = "vmc_link.create_dummy_armature"
    bl_label = "创建或重建 VRM 预览骨架"

    def execute(self, context):
        try:
            preview_arm = getattr(context.scene, "vmc_link_preview_armature", None)
            rebuild = dummy_vrm.is_vrm_intermediate_rig(preview_arm)
            arm_obj = dummy_vrm.create_intermediate_rig(context, rebuild=rebuild)
            self.report({"INFO"}, f"已{'重建' if rebuild else '创建'} VRM 预览骨架：{arm_obj.name}")
        except Exception as exc:
            self.report({"ERROR"}, f"创建 VRM 预览骨架失败：{exc}")
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_calibrate_dummy_armature_lengths(bpy.types.Operator):
    bl_idname = "vmc_link.calibrate_dummy_armature_lengths"
    bl_label = "按目标骨架校准 VRM 预览骨架长度"

    def execute(self, context):
        try:
            result = dummy_vrm.calibrate_intermediate_rig_lengths(context)
            calibrated = result["calibrated_bones"]
            self.report(
                {"INFO"},
                f"已按 {result['target_rig_label']} 肩高缩放 {result['scale_ratio']:.3f}，校准 {len(calibrated)} 根骨骼，识别映射 {result['mapped_bones']} 项",
            )
        except Exception as exc:
            self.report({"ERROR"}, f"校准 VRM 预览骨架长度失败：{exc}")
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_import_arkit_preview_face(bpy.types.Operator):
    bl_idname = "vmc_link.import_arkit_preview_face"
    bl_label = "导入 ARKit 调试面部"

    def execute(self, context):
        try:
            face_obj = dummy_vrm.import_arkit_preview_face(context)
            self.report({"INFO"}, f"已绑定 ARKit 预览面部：{face_obj.name}")
        except Exception as exc:
            self.report({"ERROR"}, f"导入 ARKit 调试面部失败：{exc}")
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_rebuild_maps(bpy.types.Operator):
    bl_idname = "vmc_link.rebuild_maps"
    bl_label = "重建目标映射"

    def execute(self, context):
        mapping.rebuild_maps(context.scene)
        self.report({"INFO"}, "已重建目标映射")
        return {"FINISHED"}


class VMC_LINK_OT_inspect_arp_rig(bpy.types.Operator):
    bl_idname = "vmc_link.inspect_arp_rig"
    bl_label = "检查 ARP 骨架"

    def execute(self, context):
        scene = context.scene
        analysis = mapping_arp.analyze_armature(getattr(scene, "vmc_link_armature", None))
        if not analysis["is_target_valid"]:
            self.report({"ERROR"}, "请先绑定目标骨架")
            return {"CANCELLED"}
        if not analysis["is_arp"]:
            report_lines = mapping_arp.inspect_report_lines(analysis)
            mapping_arp.store_scene_report(scene, "ARP 骨架检查", report_lines, analysis["is_arp"])
            self.report({"ERROR"}, "当前目标骨架不是可识别的 Auto Rig Pro 标准控制骨架")
            return {"CANCELLED"}
        _ensure_target_rig_type(scene, "ARP")
        report_lines = mapping_arp.inspect_report_lines(analysis)
        mapping_arp.store_scene_report(scene, "ARP 骨架检查", report_lines, analysis["is_arp"])
        self.report({"INFO"}, f"ARP 骨架检查通过：{analysis['target_name']}")
        return {"FINISHED"}


class VMC_LINK_OT_inspect_vrm_rig(bpy.types.Operator):
    bl_idname = "vmc_link.inspect_vrm_rig"
    bl_label = "检查 VRM 骨架"

    def execute(self, context):
        scene = context.scene
        analysis = mapping_vrm.analyze_armature(getattr(scene, "vmc_link_armature", None))
        if not analysis["is_target_valid"]:
            self.report({"ERROR"}, "请先绑定目标骨架")
            return {"CANCELLED"}
        if not analysis["is_vrm"]:
            report_lines = mapping_vrm.inspect_report_lines(analysis)
            mapping_vrm.store_scene_report(scene, "VRM / 通用骨架检查", report_lines, analysis["is_vrm"])
            self.report({"ERROR"}, "当前目标骨架不是可识别的 VRM / 通用 humanoid 骨架")
            return {"CANCELLED"}
        _ensure_target_rig_type(scene, "GENERIC")
        report_lines = mapping_vrm.inspect_report_lines(analysis)
        mapping_vrm.store_scene_report(scene, "VRM / 通用骨架检查", report_lines, analysis["is_vrm"])
        self.report({"INFO"}, "VRM / 通用骨架检查通过")
        return {"FINISHED"}


class VMC_LINK_OT_autofill_vrm_bone_map(bpy.types.Operator):
    bl_idname = "vmc_link.autofill_vrm_bone_map"
    bl_label = "应用标准 VRM 映射"

    def execute(self, context):
        scene = context.scene
        try:
            result = mapping_vrm.autofill_scene_mapping(scene)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        _ensure_target_rig_type(scene, "GENERIC")
        report_lines = mapping_vrm.autofill_report_lines(result)
        mapping_vrm.store_scene_report(scene, "VRM 自动填充", report_lines, result["analysis"]["is_vrm"])
        _finalize_mapping_update(scene)
        self.report({"INFO"}, f"已应用 {len(result['written'])} 项标准 VRM 映射")
        return {"FINISHED"}


class VMC_LINK_OT_validate_vrm_bone_map(bpy.types.Operator):
    bl_idname = "vmc_link.validate_vrm_bone_map"
    bl_label = "校验当前映射"

    def execute(self, context):
        scene = context.scene
        validation = mapping_vrm.validate_scene_mapping(scene)
        report_lines = mapping_vrm.validation_report_lines(validation)
        mapping_vrm.store_scene_report(scene, "VRM 映射校验", report_lines, validation["is_vrm"])
        if not validation["is_target_valid"]:
            self.report({"ERROR"}, "请先绑定目标骨架")
            return {"CANCELLED"}
        if not validation["is_vrm"]:
            report_lines = mapping_vrm.validation_report_lines(validation)
            mapping_vrm.store_scene_report(scene, "VRM 映射校验", report_lines, validation["is_vrm"])
            self.report({"ERROR"}, "当前目标骨架不是可识别的 VRM / 通用 humanoid 骨架")
            return {"CANCELLED"}
        _ensure_target_rig_type(scene, "GENERIC")
        report_lines = mapping_vrm.validation_report_lines(validation)
        mapping_vrm.store_scene_report(scene, "VRM 映射校验", report_lines, validation["is_vrm"])
        self.report({"INFO"}, "已完成 VRM / 通用骨架映射校验")
        return {"FINISHED"}


class VMC_LINK_OT_autofill_arp_bone_map(bpy.types.Operator):
    bl_idname = "vmc_link.autofill_arp_bone_map"
    bl_label = "应用标准 ARP 映射"

    def execute(self, context):
        scene = context.scene
        try:
            result = mapping_arp.autofill_scene_mapping(scene)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        _ensure_target_rig_type(scene, "ARP")
        report_lines = mapping_arp.autofill_report_lines(result)
        mapping_arp.store_scene_report(scene, "ARP 自动填充", report_lines, result["analysis"]["is_arp"])
        _finalize_mapping_update(scene)
        self.report({"INFO"}, f"已应用 {len(result['written'])} 项标准 ARP 映射")
        return {"FINISHED"}


class VMC_LINK_OT_validate_arp_bone_map(bpy.types.Operator):
    bl_idname = "vmc_link.validate_arp_bone_map"
    bl_label = "校验当前映射"

    def execute(self, context):
        scene = context.scene
        validation = mapping_arp.validate_scene_mapping(scene)
        if not validation["is_target_valid"]:
            self.report({"ERROR"}, "请先绑定目标骨架")
            return {"CANCELLED"}
        if not validation["is_arp"]:
            report_lines = mapping_arp.validation_report_lines(validation)
            mapping_arp.store_scene_report(scene, "ARP 映射校验", report_lines, validation["is_arp"])
            self.report({"ERROR"}, "当前目标骨架不是可识别的 Auto Rig Pro 标准控制骨架")
            return {"CANCELLED"}
        _ensure_target_rig_type(scene, "ARP")
        report_lines = mapping_arp.validation_report_lines(validation)
        mapping_arp.store_scene_report(scene, "ARP 映射校验", report_lines, validation["is_arp"])
        self.report({"INFO"}, "已完成 ARP 映射校验")
        return {"FINISHED"}


class VMC_LINK_OT_inspect_mmd_rig(bpy.types.Operator):
    bl_idname = "vmc_link.inspect_mmd_rig"
    bl_label = "检查 MMD 骨架"

    def execute(self, context):
        scene = context.scene
        analysis = mapping_mmd.analyze_armature(getattr(scene, "vmc_link_armature", None))
        if not analysis["is_target_valid"]:
            self.report({"ERROR"}, "请先绑定目标骨架")
            return {"CANCELLED"}
        if not analysis["is_mmd"]:
            report_lines = mapping_mmd.inspect_report_lines(analysis)
            mapping_mmd.store_scene_report(scene, "MMD 骨架检查", report_lines, analysis["is_mmd"])
            self.report({"ERROR"}, "当前目标骨架不是可识别的 MMD 标准骨架")
            return {"CANCELLED"}
        _ensure_target_rig_type(scene, "MMD")
        report_lines = mapping_mmd.inspect_report_lines(analysis)
        mapping_mmd.store_scene_report(scene, "MMD 骨架检查", report_lines, analysis["is_mmd"])
        runtime.refresh_receiver_target_context(scene)
        self.report({"INFO"}, "MMD 骨架检查通过")
        return {"FINISHED"}


class VMC_LINK_OT_autofill_mmd_bone_map(bpy.types.Operator):
    bl_idname = "vmc_link.autofill_mmd_bone_map"
    bl_label = "应用标准 MMD 映射"

    def execute(self, context):
        scene = context.scene
        try:
            result = mapping_mmd.autofill_scene_mapping(scene)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        _ensure_target_rig_type(scene, "MMD")
        report_lines = mapping_mmd.autofill_report_lines(result)
        mapping_mmd.store_scene_report(scene, "MMD 自动填充", report_lines, result["analysis"]["is_mmd"])
        _finalize_mapping_update(scene)
        self.report({"INFO"}, f"已重建 {len(result['written'])} 项标准 MMD 映射")
        return {"FINISHED"}


class VMC_LINK_OT_validate_mmd_bone_map(bpy.types.Operator):
    bl_idname = "vmc_link.validate_mmd_bone_map"
    bl_label = "校验当前 MMD 映射"

    def execute(self, context):
        scene = context.scene
        validation = mapping_mmd.validate_scene_mapping(scene)
        if not validation["is_target_valid"]:
            self.report({"ERROR"}, "请先绑定目标骨架")
            return {"CANCELLED"}
        if not validation["is_mmd"]:
            report_lines = mapping_mmd.validation_report_lines(validation)
            mapping_mmd.store_scene_report(scene, "MMD 映射校验", report_lines, validation["is_mmd"])
            self.report({"ERROR"}, "当前目标骨架不是可识别的 MMD 标准骨架")
            return {"CANCELLED"}
        _ensure_target_rig_type(scene, "MMD")
        report_lines = mapping_mmd.validation_report_lines(validation)
        mapping_mmd.store_scene_report(scene, "MMD 映射校验", report_lines, validation["is_mmd"])
        runtime.refresh_receiver_target_context(scene)
        self.report({"INFO"}, "已完成 MMD 映射校验")
        return {"FINISHED"}


class VMC_LINK_OT_toggle_recording(bpy.types.Operator):
    bl_idname = "vmc_link.toggle_recording"
    bl_label = "切换录制"

    def execute(self, context):
        scene = context.scene
        try:
            if runtime.is_recording():
                written_frames = runtime.get_recording_sample_count()
                runtime._stop_recording_session(scene)
                self.report({"INFO"}, f"停止录制：已缓存 {written_frames} 帧，正在保存")
            else:
                scene.frame_set(int(runtime.get_recording_start_frame(scene)))
                if network.is_paused():
                    network.resume_server(scene)
                elif not network.is_session_active():
                    network.start_server(scene)
                runtime.start_recording(scene)
                self.report(
                    {"INFO"},
                    f"开始录制：范围 {runtime.get_recording_start_frame(scene)} - {runtime.get_recording_end_frame(scene)}",
                )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class VMC_LINK_OT_new_recording_action(bpy.types.Operator):
    bl_idname = "vmc_link.new_recording_action"
    bl_label = "新建录制 Action"

    target: bpy.props.EnumProperty(
        items=(
            ("ARMATURE", "目标骨架", "为目标骨架新建 Action"),
            ("FACE", "目标面部", "为目标面部新建 Shape Key Action"),
        ),
    )

    def execute(self, context):
        scene = context.scene
        if self.target == "ARMATURE":
            arm = getattr(scene, "vmc_link_armature", None)
            if not mapping.has_pose_bones(arm):
                self.report({"ERROR"}, "请先绑定目标骨架")
                return {"CANCELLED"}
            action = bpy.data.actions.new(f"{arm.name}_VMC_Link_Action")
            scene.vmc_link_record_armature_action = action
        else:
            face = getattr(scene, "vmc_link_face_object", None)
            if not mapping.has_shape_keys(face):
                self.report({"ERROR"}, "请先绑定带 Shape Key 的目标面部")
                return {"CANCELLED"}
            action = bpy.data.actions.new(f"{face.name}_VMC_Link_ShapeKeys")
            scene.vmc_link_record_face_action = action

        action.use_fake_user = True
        self.report({"INFO"}, f"已新建录制 Action：{action.name}")
        return {"FINISHED"}


class VMC_LINK_OT_set_record_start_to_current_frame(bpy.types.Operator):
    bl_idname = "vmc_link.set_record_start_to_current_frame"
    bl_label = "当前帧设为开始"

    def execute(self, context):
        scene = context.scene
        scene.vmc_link_record_start_frame = int(scene.frame_current)
        self.report({"INFO"}, f"已将录制开始帧设为 {scene.frame_current}")
        return {"FINISHED"}


class VMC_LINK_OT_set_record_end_to_current_frame(bpy.types.Operator):
    bl_idname = "vmc_link.set_record_end_to_current_frame"
    bl_label = "当前帧设为结束"

    def execute(self, context):
        scene = context.scene
        scene.vmc_link_record_end_frame = int(scene.frame_current)
        self.report({"INFO"}, f"已将录制结束帧设为 {scene.frame_current}")
        return {"FINISHED"}


class VMC_LINK_OT_clear_recording_range_keys(bpy.types.Operator):
    bl_idname = "vmc_link.clear_recording_range_keys"
    bl_label = "清空范围内关键帧"

    def execute(self, context):
        try:
            scene = context.scene
            frame_start = int(runtime.get_recording_start_frame(scene))
            scene.frame_set(frame_start)
            result = runtime.clear_recording_range_keys(scene)
            scene.frame_set(frame_start)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        removed_total = int(result["armature_removed"]) + int(result["face_removed"])
        if removed_total == 0:
            self.report({"INFO"}, f"指定范围内没有可清除的录制关键帧：{result['frame_start']} - {result['frame_end']}")
        else:
            self.report(
                {"INFO"},
                f"已清空范围 {result['frame_start']} - {result['frame_end']} 内的 {removed_total} 个录制关键帧",
            )
        return {"FINISHED"}


CLASSES = (
    VMC_LINK_OT_toggle_receiver,
    VMC_LINK_OT_start_receiver,
    VMC_LINK_OT_pause_receiver,
    VMC_LINK_OT_stop_receiver,
    VMC_LINK_OT_refresh_mapping_presets,
    VMC_LINK_OT_save_mapping_preset,
    VMC_LINK_OT_load_mapping_preset,
    VMC_LINK_OT_create_dummy_armature,
    VMC_LINK_OT_calibrate_dummy_armature_lengths,
    VMC_LINK_OT_import_arkit_preview_face,
    VMC_LINK_OT_rebuild_maps,
    VMC_LINK_OT_inspect_vrm_rig,
    VMC_LINK_OT_autofill_vrm_bone_map,
    VMC_LINK_OT_validate_vrm_bone_map,
    VMC_LINK_OT_inspect_arp_rig,
    VMC_LINK_OT_autofill_arp_bone_map,
    VMC_LINK_OT_validate_arp_bone_map,
    VMC_LINK_OT_inspect_mmd_rig,
    VMC_LINK_OT_autofill_mmd_bone_map,
    VMC_LINK_OT_validate_mmd_bone_map,
    VMC_LINK_OT_toggle_recording,
    VMC_LINK_OT_new_recording_action,
    VMC_LINK_OT_set_record_start_to_current_frame,
    VMC_LINK_OT_set_record_end_to_current_frame,
    VMC_LINK_OT_clear_recording_range_keys,
)
