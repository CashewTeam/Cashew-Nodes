import bpy
import json
import os
from queue import Empty, Queue
from threading import Thread
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from bpy.types import Operator, Panel, UIList, PropertyGroup
from bpy.props import StringProperty, CollectionProperty, IntProperty, PointerProperty

bl_info = {
    "name": "Scene Translation Assistant 场景翻译助手",
    "blender": (2, 80, 0),
    "category": "Tool",
    "author": "Con11 & DeepSeek R1",
    "version": (1, 1),
    "description": "Combined material and scene translation tools",
}

# 公共工具函数 ===========================================
def copy_to_clipboard(text: str):
    bpy.context.window_manager.clipboard = text

def read_clipboard() -> str:
    return bpy.context.window_manager.clipboard


API_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "api_config.json")
DEFAULT_API_CONFIG = {
    "base_url": "https://api.deepseek.com",
    "api_key": "",
    "model": "deepseek-v4-flash",
    "batch_size": 10,
    "target_language": "Chinese",
}


def load_api_config():
    config = DEFAULT_API_CONFIG.copy()
    try:
        with open(API_CONFIG_PATH, "r", encoding="utf-8") as file:
            saved_config = json.load(file)
        if isinstance(saved_config, dict):
            config.update({key: value for key, value in saved_config.items() if key in config})
    except FileNotFoundError:
        pass
    except (OSError, json.JSONDecodeError):
        pass
    return config


def save_api_config(settings):
    with open(API_CONFIG_PATH, "w", encoding="utf-8") as file:
        json.dump({
            "base_url": settings.base_url.strip(),
            "api_key": settings.api_key.strip(),
            "model": settings.model.strip(),
            "batch_size": settings.batch_size,
            "target_language": settings.target_language.strip(),
        }, file, ensure_ascii=False, indent=2)


_translation_job = None


def api_config_from_settings(settings):
    return {
        "base_url": settings.base_url.strip(),
        "api_key": settings.api_key.strip(),
        "model": settings.model.strip(),
        "batch_size": settings.batch_size,
        "target_language": settings.target_language.strip(),
    }


def validate_translation_settings(settings):
    if not bpy.app.online_access:
        raise RuntimeError("Enable Blender's Allow Online Access setting first")
    config = api_config_from_settings(settings)
    if not config["base_url"] or not config["api_key"] or not config["model"]:
        raise RuntimeError("Set API Base URL, API Key, and model first")
    return config


def request_translation_batch(texts, config):

    payload = {
        "model": config["model"],
        "messages": [
            {"role": "system", "content": "Translate Blender asset names. When translating into a Latin-script language, output only ASCII characters. Return only a JSON array of translated strings in the same order and length as the input."},
            {"role": "user", "content": json.dumps({"target_language": config["target_language"], "texts": texts}, ensure_ascii=False)},
        ],
        "stream": False,
    }
    if payload["model"].startswith("deepseek-v4"):
        payload["thinking"] = {"type": "disabled"}
    request_data = json.dumps(payload).encode("utf-8")
    endpoint = config["base_url"].rstrip("/") + "/chat/completions"
    request = Request(endpoint, data=request_data, headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer " + config["api_key"],
    })
    try:
        with urlopen(request, timeout=60) as response:
            body = json.load(response)
    except HTTPError as error:
        raise RuntimeError(f"API request failed: HTTP {error.code}") from error
    except URLError as error:
        raise RuntimeError(f"API connection failed: {error.reason}") from error

    try:
        translated = json.loads(body["choices"][0]["message"]["content"])
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as error:
        raise RuntimeError("API response was not a JSON translation list") from error
    if not isinstance(translated, list) or len(translated) != len(texts) or not all(isinstance(text, str) for text in translated):
        raise RuntimeError("API response count does not match the input")
    return translated


def poll_translation_job():
    global _translation_job
    job = _translation_job
    if job is None:
        return None

    try:
        while True:
            kind, value = job["updates"].get_nowait()
            if kind == "progress":
                bpy.context.window_manager.translation_api_status = f"Translating {value}/{len(job['originals'])}"
            elif kind == "error":
                bpy.context.window_manager.translation_api_status = f"Translation failed: {value}"
                _translation_job = None
                return None
            elif kind == "complete":
                items = bpy.context.scene.material_text_items if job["scope"] == "material" else bpy.context.window_manager.scene_translation_items
                if [getattr(item, job["original_property"]) for item in items] != job["originals"]:
                    bpy.context.window_manager.translation_api_status = "Translation result discarded because the list changed"
                else:
                    for item, translated in zip(items, value):
                        setattr(item, job["translated_property"], translated)
                    bpy.context.window_manager.translation_api_status = f"Translated {len(value)} names"
                _translation_job = None
                return None
    except Empty:
        pass
    return 0.1


def start_translation_job(scope, items, original_property, translated_property, settings):
    global _translation_job
    if _translation_job is not None:
        raise RuntimeError("A translation is already running")

    config = validate_translation_settings(settings)
    originals = [getattr(item, original_property) for item in items]
    job = {
        "scope": scope,
        "originals": originals,
        "original_property": original_property,
        "translated_property": translated_property,
        "config": config,
        "updates": Queue(),
    }

    def run():
        try:
            translated = []
            for start in range(0, len(originals), config["batch_size"]):
                translated.extend(request_translation_batch(originals[start:start + config["batch_size"]], config))
                job["updates"].put(("progress", len(translated)))
            job["updates"].put(("complete", translated))
        except (RuntimeError, OSError, ValueError) as error:
            job["updates"].put(("error", str(error)))

    job["thread"] = Thread(target=run, daemon=True)
    _translation_job = job
    bpy.context.window_manager.translation_api_status = f"Translating 0/{len(originals)}"
    job["thread"].start()
    bpy.app.timers.register(poll_translation_job, first_interval=0.1)


class TranslationAPISettings(PropertyGroup):
    base_url: StringProperty(name="API Base URL", default=DEFAULT_API_CONFIG["base_url"], options={'SKIP_SAVE'})
    api_key: StringProperty(name="API Key", subtype='PASSWORD', options={'SKIP_SAVE'})
    model: StringProperty(name="Model", default=DEFAULT_API_CONFIG["model"], options={'SKIP_SAVE'})
    batch_size: IntProperty(name="Items per Request", default=DEFAULT_API_CONFIG["batch_size"], min=1, max=100, options={'SKIP_SAVE'})
    target_language: StringProperty(name="Target Language", default=DEFAULT_API_CONFIG["target_language"], options={'SKIP_SAVE'})


class TRANSLATION_OT_SaveApiConfig(Operator):
    bl_idname = "translation.save_api_config"
    bl_label = "Save API Configuration"

    def execute(self, context):
        try:
            save_api_config(context.window_manager.translation_api_settings)
        except OSError as error:
            self.report({'ERROR'}, f"Could not save API configuration: {error}")
            return {'CANCELLED'}
        self.report({'INFO'}, "API configuration saved locally")
        return {'FINISHED'}


def draw_api_settings(layout, settings):
    box = layout.box()
    box.label(text="OpenAI-Compatible API")
    box.prop(settings, "base_url")
    box.prop(settings, "api_key")
    box.prop(settings, "model")
    box.prop(settings, "batch_size")
    box.prop(settings, "target_language")
    box.operator(TRANSLATION_OT_SaveApiConfig.bl_idname, icon='FILE_TICK')
    status = bpy.context.window_manager.translation_api_status
    if status:
        box.label(text=status, icon='INFO')

# ========================================================
# 材质翻译插件部分
# ========================================================
class MaterialTextItem(PropertyGroup):
    original_text: StringProperty()
    translated_text: StringProperty()
    filepath: StringProperty()

class MATERIAL_UL_TranslationList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "original_text", text="", emboss=False)
            row.prop(item, "translated_text", text="", emboss=True)
        else:
            layout.label(text="")

class MATERIAL_OT_ExtractTexts(Operator):
    bl_idname = "material.extract_texts"
    bl_label = "Extract & Copy Texture Texts"
    
    def execute(self, context):
        scene = context.scene
        scene.material_text_items.clear()
        
        for img in bpy.data.images:
            if img.source == 'FILE' and not img.packed_file:
                filepath = bpy.path.abspath(img.filepath)
                filename = os.path.basename(filepath)
                name, ext = os.path.splitext(filename)
                
                item = scene.material_text_items.add()
                item.original_text = name
                item.translated_text = name
                item.filepath = filepath
        
        text = '\n'.join([item.original_text for item in scene.material_text_items])
        copy_to_clipboard(text)
        return {'FINISHED'}

class MATERIAL_OT_PasteTexts(Operator):
    bl_idname = "material.paste_texts"
    bl_label = "Paste Texture Texts"
    
    def execute(self, context):
        text = read_clipboard()
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        items = context.scene.material_text_items
        for i in range(min(len(lines), len(items))):
            items[i].translated_text = lines[i]
        return {'FINISHED'}

class MATERIAL_OT_TranslateTexts(Operator):
    bl_idname = "material.translate_texts"
    bl_label = "Translate Texture Texts"

    def execute(self, context):
        items = context.scene.material_text_items
        if not items:
            self.report({'WARNING'}, "Extract texture texts first")
            return {'CANCELLED'}
        try:
            start_translation_job("material", items, "original_text", "translated_text", context.window_manager.translation_api_settings)
        except RuntimeError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        return {'FINISHED'}

class MATERIAL_OT_ReplaceTexts(Operator):
    bl_idname = "material.replace_texts"
    bl_label = "Apply Texture Renaming"
    
    def execute(self, context):
        for item in context.scene.material_text_items:
            if item.translated_text and item.original_text != item.translated_text:
                old_abs_path = item.filepath
                dirname = os.path.dirname(old_abs_path)
                ext = os.path.splitext(old_abs_path)[1]
                new_abs_path = os.path.join(dirname, f"{item.translated_text}{ext}")
                
                try:
                    if os.path.exists(old_abs_path):
                        os.rename(old_abs_path, new_abs_path)
                        new_rel_path = bpy.path.relpath(new_abs_path)
                        
                        for img in bpy.data.images:
                            if bpy.path.abspath(img.filepath) == old_abs_path:
                                img.filepath = new_rel_path
                                img.name = item.translated_text
                                img.reload()
                        
                        item.filepath = new_abs_path
                        item.original_text = item.translated_text
                except Exception as e:
                    self.report({'ERROR'}, f"Error: {str(e)}")
        return {'FINISHED'}

class NODE_PT_MaterialTranslation(Panel):
    bl_label = "Texture Translator"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Tool"
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        layout.operator(MATERIAL_OT_ExtractTexts.bl_idname, icon='COPYDOWN')
        layout.operator(MATERIAL_OT_TranslateTexts.bl_idname, icon='OUTLINER_OB_FONT')
        layout.operator(MATERIAL_OT_PasteTexts.bl_idname, icon='PASTEDOWN')
        layout.template_list(
            "MATERIAL_UL_TranslationList", 
            "", 
            scene, 
            "material_text_items", 
            scene, 
            "material_text_items_index"
        )
        layout.operator(MATERIAL_OT_ReplaceTexts.bl_idname, icon='FILE_REFRESH')
        draw_api_settings(layout, context.window_manager.translation_api_settings)

# ========================================================
# 场景翻译插件部分
# ========================================================
class SceneTranslationItem(PropertyGroup):
    original: StringProperty()
    translated: StringProperty()

class SCENE_UL_TranslationList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=item.original)
            row.prop(item, "translated", text="", emboss=True)
        else:
            layout.label(text="")

class SCENE_OT_ExtractTexts(Operator):
    bl_idname = "scene.extract_texts"
    bl_label = "Extract & Copy Scene Texts"
    
    def execute(self, context):
        wm = context.window_manager
        wm.scene_translation_items.clear()
        
        names = []
        names.extend(obj.name for obj in bpy.data.objects)
        names.extend(mat.name for mat in bpy.data.materials)
        names.extend(col.name for col in bpy.data.collections)
        
        seen = set()
        for name in sorted(list(set(names)), key=names.index):
            if name not in seen:
                seen.add(name)
                item = wm.scene_translation_items.add()
                item.original = name
        
        text = "\n".join([item.original for item in wm.scene_translation_items])
        copy_to_clipboard(text)
        return {'FINISHED'}

class SCENE_OT_PasteTexts(Operator):
    bl_idname = "scene.paste_texts"
    bl_label = "Paste Scene Texts"
    
    def execute(self, context):
        text = read_clipboard()
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        
        items = context.window_manager.scene_translation_items
        for i in range(min(len(lines), len(items))):
            items[i].translated = lines[i]
        return {'FINISHED'}

class SCENE_OT_TranslateTexts(Operator):
    bl_idname = "scene.translate_texts"
    bl_label = "Translate Scene Texts"

    def execute(self, context):
        items = context.window_manager.scene_translation_items
        if not items:
            self.report({'WARNING'}, "Extract scene texts first")
            return {'CANCELLED'}
        try:
            start_translation_job("scene", items, "original", "translated", context.window_manager.translation_api_settings)
        except RuntimeError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        return {'FINISHED'}

class SCENE_OT_ReplaceTexts(Operator):
    bl_idname = "scene.replace_texts"
    bl_label = "Apply Scene Renaming"
    
    def execute(self, context):
        wm = context.window_manager
        name_map = {item.original: item.translated for item in wm.scene_translation_items if item.translated.strip()}
        
        for obj in bpy.data.objects:
            if obj.name in name_map:
                obj.name = name_map[obj.name]
        
        for mat in bpy.data.materials:
            if mat.name in name_map:
                mat.name = name_map[mat.name]
        
        for col in bpy.data.collections:
            if col.name in name_map:
                col.name = name_map[col.name]
        
        return {'FINISHED'}

class VIEW3D_PT_SceneTranslation(Panel):
    bl_label = "Scene Translator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        layout.operator(SCENE_OT_ExtractTexts.bl_idname, icon='COPYDOWN')
        layout.operator(SCENE_OT_TranslateTexts.bl_idname, icon='OUTLINER_OB_FONT')
        layout.operator(SCENE_OT_PasteTexts.bl_idname, icon='PASTEDOWN')
        layout.template_list(
            "SCENE_UL_TranslationList",
            "",
            wm,
            "scene_translation_items",
            wm,
            "scene_translation_index"
        )
        layout.operator(SCENE_OT_ReplaceTexts.bl_idname, icon='FILE_REFRESH')
        draw_api_settings(layout, context.window_manager.translation_api_settings)

# ========================================================
# 注册和注销
# ========================================================
classes = (
    TranslationAPISettings,
    TRANSLATION_OT_SaveApiConfig,
    # 材质翻译插件
    MaterialTextItem,
    MATERIAL_UL_TranslationList,
    MATERIAL_OT_ExtractTexts,
    MATERIAL_OT_PasteTexts,
    MATERIAL_OT_TranslateTexts,
    MATERIAL_OT_ReplaceTexts,
    NODE_PT_MaterialTranslation,
    
    # 场景翻译插件
    SceneTranslationItem,
    SCENE_UL_TranslationList,
    SCENE_OT_ExtractTexts,
    SCENE_OT_PasteTexts,
    SCENE_OT_TranslateTexts,
    SCENE_OT_ReplaceTexts,
    VIEW3D_PT_SceneTranslation
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # 材质翻译数据存储在Scene
    bpy.types.Scene.material_text_items = CollectionProperty(type=MaterialTextItem)
    bpy.types.Scene.material_text_items_index = IntProperty()
    
    # 场景翻译数据存储在WindowManager
    bpy.types.WindowManager.scene_translation_items = CollectionProperty(type=SceneTranslationItem)
    bpy.types.WindowManager.scene_translation_index = IntProperty()
    bpy.types.WindowManager.translation_api_settings = PointerProperty(type=TranslationAPISettings)
    bpy.types.WindowManager.translation_api_status = StringProperty(options={'SKIP_SAVE'})

    config = load_api_config()
    settings = bpy.context.window_manager.translation_api_settings
    settings.base_url = config["base_url"]
    settings.api_key = config["api_key"]
    settings.model = config["model"]
    settings.batch_size = config["batch_size"]
    settings.target_language = config["target_language"]

def unregister():
    global _translation_job
    _translation_job = None
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.material_text_items
    del bpy.types.Scene.material_text_items_index
    del bpy.types.WindowManager.scene_translation_items
    del bpy.types.WindowManager.scene_translation_index
    del bpy.types.WindowManager.translation_api_settings
    del bpy.types.WindowManager.translation_api_status

if __name__ == "__main__":
    register()
